#!/usr/bin/env python3
import argparse
import datetime as dt
import json
from pathlib import Path

import openpyxl


DATE_FORMAT = "%Y年%m月%d日%H时%M分%S秒"
REQUIRED = ["笔记标题", "首次发布时间", "曝光", "观看量", "封面点击率", "点赞", "评论", "收藏", "涨粉", "分享", "人均观看时长"]


def number(value):
    if value in (None, ""):
        return 0.0
    return float(value)


def load_rows(path):
    sheet = openpyxl.load_workbook(path, data_only=True, rich_text=True).active
    headers = {str(sheet.cell(2, col).value).strip(): col for col in range(1, sheet.max_column + 1)}
    missing = [name for name in REQUIRED if name not in headers]
    if missing:
        raise ValueError(f"缺少字段: {', '.join(missing)}")
    rows = []
    for row in range(3, sheet.max_row + 1):
        raw_date = sheet.cell(row, headers["首次发布时间"]).value
        if raw_date in (None, ""):
            continue
        published = raw_date if isinstance(raw_date, dt.datetime) else dt.datetime.strptime(str(raw_date), DATE_FORMAT)
        rows.append({name: sheet.cell(row, col).value for name, col in headers.items()} | {"_published": published})
    return rows


def metrics(rows, month, account):
    selected = [row for row in rows if row["_published"].strftime("%Y-%m") == month]
    count = len(selected)
    if not count:
        return {"month": month, "account": account, "note_count": 0, "metrics": None}
    total_views = sum(number(row["观看量"]) for row in selected)
    interaction_fields = ["点赞", "收藏", "分享"] if account == "major" else ["点赞", "评论", "收藏", "分享"]
    result = {
        "average_exposure": sum(number(row["曝光"]) for row in selected) / count,
        "average_views": total_views / count,
        "average_cover_ctr": sum(number(row["封面点击率"]) for row in selected) / count,
        "interaction_rate": (sum(sum(number(row[field]) for field in interaction_fields) for row in selected) / total_views) if total_views else None,
        "follower_conversion_rate": (sum(number(row["涨粉"]) for row in selected) / total_views) if total_views else None,
        "average_watch_time": sum(number(row["人均观看时长"]) for row in selected) / count,
    }
    return {"month": month, "account": account, "note_count": count, "metrics": result}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--major", required=True, type=Path)
    parser.add_argument("--minor", required=True, type=Path)
    parser.add_argument("--month", help="YYYY-MM；省略时使用两份文件中的最新发布日期月份")
    args = parser.parse_args()
    major_rows = load_rows(args.major)
    minor_rows = load_rows(args.minor)
    if not major_rows and not minor_rows:
        raise ValueError("两份文件都没有可用记录")
    month = args.month or max(row["_published"] for row in major_rows + minor_rows).strftime("%Y-%m")
    output = {"target_month": month, "major": metrics(major_rows, month, "major"), "minor": metrics(minor_rows, month, "minor")}
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
